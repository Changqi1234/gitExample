#!/bin/bash
rm -rf *.csv
rm -rf *.out
