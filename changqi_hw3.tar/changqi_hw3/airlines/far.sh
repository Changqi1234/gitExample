#!/bin/bash
sort -n -t, -k 19 -r allMSN.csv|awk 'NR==2' > farthest.txt
