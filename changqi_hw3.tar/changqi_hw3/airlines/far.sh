#!/bin/bash
sort -nr -k5,5 allMSN.csv | awk 'NR==2' > farthest.txt
