#!/bin/bash
cd "${SLURM_SUBMIT_DIR:?SLURM_SUBMIT_DIR not set}"
Rscript -e 'df=read.table("allMSN.csv",header=TRUE,sep="");
    	print(tapply(X=df$DepDelay,INDEX=df$DayOfWeek,FUN=mean,na.rm=TRUE));' > delays.txt
