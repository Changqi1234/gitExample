#!/bin/bash
a=$(sbatch --parsable --array=0-21 get.sh)
b=$(sbatch --parsable --partition short --dependency=afterok:${a} combine.sh)
c=$(sbatch --parsable --partition short --dependency=afterok:${b} far.sh)
d=$(sbatch --parsable --partition short --dependency=afterok:${c} average.sh)
e=$(sbatch --parsable --partition short --dependency=afterok:${d} del.sh)
