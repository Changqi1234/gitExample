#!/bin/bash
i=$SLURM_ARRAY_TASK_ID
wget http://pages.stat.wisc.edu/~jgillett/DSCP/HPC/airlines/$((i+1987)).csv.bz2
bzip2 -d $((i+1987)).csv.bz2
awk -F, '($17=="MSN")||($17=="Origin") {print $4,$16,$17,$18,$19}' $((i+1987)).csv > MSN$((i+1987)).csv
