#!/bin/bash
head -n1 MSN1987.csv > allMSN.csv
for i in {0..21}
do
    tail -n +2 MSN$((i+1987)).csv >> allMSN.csv
done
