#!/bin/bash
i=$SLURM_ARRAY_TASK_ID
awk -F, '$11==3{print $7}' mtcars${i}.csv >out${i}.csv
