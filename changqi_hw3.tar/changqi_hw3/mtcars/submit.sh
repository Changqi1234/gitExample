#!/bin/bash
a=$(sbatch --parsable getData.sh)
b=$(sbatch --parsable --dependency=afterok:$a --array=1-3 jobArray.sh)
c=$(sbatch --parsable --dependency=afterok:$b findLightest.sh)
