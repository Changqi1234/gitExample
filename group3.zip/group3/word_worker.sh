#!/bin/bash
set -euo pipefail

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 INPUT_FILE OUTPUT_FILE"
    exit 1
fi

INFILE="$1"
OUTFILE="$2"

if [ ! -f "$INFILE" ]; then
    echo "ERROR: input file $INFILE does not exist."
    exit 1
fi

export LC_ALL=C

tr '[:upper:]' '[:lower:]' < "$INFILE" \
    | sed 's/[[:punct:]]/ /g' \
    | sed 's/[[:space:]]\+/\n/g' \
    | grep -v '^[[:space:]]*$' \
    | sort \
    > "$OUTFILE"

echo "Processed $INFILE -> $OUTFILE"
