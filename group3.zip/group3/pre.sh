#!/bin/bash
set -euo pipefail

CHUNKS=5

wget -O shakespeare.tar "https://pages.stat.wisc.edu/~jgillett/DSCP/CHTC/wordCounting/shakespeare.tar"
tar -xf shakespeare.tar

find shakespeare -type f ! -name "README" -print0 | xargs -0 cat > all_plays.txt

rm -f chunk_*.txt

split -n l/${CHUNKS} all_plays.txt chunk_

i=0
for f in chunk_*; do
    mv "$f" "chunk_${i}.txt"
    i=$((i+1))
done

ls chunk_*.txt

mkdir -p logs
